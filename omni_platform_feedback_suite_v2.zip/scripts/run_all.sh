#!/usr/bin/env bash
set -e

# Simple helper to run all core components with basic defaults.
# You may prefer to run these in separate terminals or a process manager.

echo "[RUN] Indexing policy..."
python3 controller/policy_indexer.py

echo "[RUN] Starting metrics aggregator (background)..."
python3 controller/metrics_aggregator.py &

sleep 1

echo "[RUN] Starting smart controller (background)..."
python3 controller/smart_controller.py &

sleep 1

echo "[RUN] Starting web dashboard..."
python3 ui/web_dashboard.py
