async function fetchState() {
  try {
    const res = await fetch('/api/state');
    if (!res.ok) {
      throw new Error('HTTP ' + res.status);
    }
    const data = await res.json();

    const policyMetaEl = document.getElementById('policy-meta');
    const metricsEl = document.getElementById('metrics-body');
    const licenseEl = document.getElementById('license-body');
    const eventsEl = document.getElementById('events-body');

    const meta = (data.policy && data.policy.meta) || {};
    policyMetaEl.textContent = JSON.stringify(meta, null, 2);

    metricsEl.textContent = JSON.stringify(data.metrics || {}, null, 2);
    licenseEl.textContent = JSON.stringify({
      license_meta: data.license && data.license.license_meta,
      license_caps: data.license_caps
    }, null, 2);

    eventsEl.textContent = JSON.stringify(data.events || [], null, 2);
  } catch (err) {
    console.error(err);
  }
}

setInterval(fetchState, 3000);
fetchState();
