import http.server
import json
import os
import socketserver
from typing import Any, Dict

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

SETTINGS = _load_settings()

def _load_json(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

class Handler(http.server.SimpleHTTPRequestHandler):
    def _set_json_headers(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def _set_html_headers(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

    def do_GET(self):
        if self.path == "/api/state":
            policy_path = os.path.join(BASE_DIR, SETTINGS["paths"]["policy_index_json"])
            metrics_path = os.path.join(BASE_DIR, SETTINGS["paths"]["metrics_snapshot_json"])
            license_path = os.path.join(BASE_DIR, SETTINGS["paths"]["license_json"])
            bus_events_path = os.path.join(BASE_DIR, SETTINGS["paths"]["bus_events_log"])

            from controller import ubus  # type: ignore
            from controller import license_authority  # type: ignore

            policy = _load_json(policy_path)
            metrics = _load_json(metrics_path)
            license_data = _load_json(license_path)
            events = ubus.iter_events(limit=20)
            caps = license_authority.get_capabilities()

            state = {
                "policy": policy,
                "metrics": metrics,
                "license": license_data,
                "license_caps": caps,
                "events": events
            }
            self._set_json_headers()
            self.wfile.write(json.dumps(state).encode("utf-8"))
            return

        # Serve static UI
        if self.path in ("/", "/index.html"):
            self.path = "/static/index.html"
        elif self.path.startswith("/static/"):
            # serve as is
            pass
        else:
            # fallback to index
            self.path = "/static/index.html"

        return http.server.SimpleHTTPRequestHandler.do_GET(self)

def run(port: int = 8080):
    os.chdir(os.path.join(BASE_DIR, "ui"))
    with socketserver.TCPServer(("", port), Handler) as httpd:
        print(f"[WEB] Dashboard serving on http://127.0.0.1:{port}/")
        httpd.serve_forever()

if __name__ == "__main__":
    run()
