import json
import os
import re
import time
from typing import Any, Dict

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

CYCLE_RE = re.compile(r"Cycle complete", re.IGNORECASE)
NET_DISC_RE = re.compile(r"NET: discovery .*up=(\d+)", re.IGNORECASE)
FIM_RE = re.compile(r"FIM: (?P<path>\S+) sha256=(?P<hash>[0-9a-fA-F]{32,64})")
SEC_FIREWALL_RE = re.compile(r"SEC: firewall tightened", re.IGNORECASE)
SEC_SUSPICIOUS_RE = re.compile(r"SEC: suspicious process", re.IGNORECASE)

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def _parse_log(log_path: str) -> Dict[str, Any]:
    metrics: Dict[str, Any] = {
        "cycles_total": 0,
        "network": {
            "last_scan_cidr": None,
            "last_up_hosts": None
        },
        "security": {
            "firewall_tighten_events": 0,
            "suspicious_process_events": 0
        },
        "fim": {}  # path -> hash
    }

    if not os.path.exists(log_path):
        return metrics

    with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if CYCLE_RE.search(line):
                metrics["cycles_total"] += 1

            m_net = NET_DISC_RE.search(line)
            if m_net:
                up = int(m_net.group(1))
                metrics["network"]["last_up_hosts"] = up
                # crude CIDR extraction if present
                cidr_match = re.search(r"(\d+\.\d+\.\d+\.\d+/\d+)", line)
                if cidr_match:
                    metrics["network"]["last_scan_cidr"] = cidr_match.group(1)

            if SEC_FIREWALL_RE.search(line):
                metrics["security"]["firewall_tighten_events"] += 1

            if SEC_SUSPICIOUS_RE.search(line):
                metrics["security"]["suspicious_process_events"] += 1

            m_fim = FIM_RE.search(line)
            if m_fim:
                metrics["fim"][m_fim.group("path")] = m_fim.group("hash")

    return metrics

def write_snapshot(settings: Dict[str, Any]) -> None:
    log_path = os.path.join(BASE_DIR, settings["paths"]["daemon_log"])
    snapshot_path = os.path.join(BASE_DIR, settings["paths"]["metrics_snapshot_json"])

    metrics = _parse_log(log_path)
    metrics["timestamp_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    os.makedirs(os.path.dirname(snapshot_path), exist_ok=True)
    with open(snapshot_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, sort_keys=True)

    print(f"[METRICS] Updated snapshot: {snapshot_path}")

def main():
    settings = _load_settings()
    interval = settings["controller"].get("metrics_update_interval_sec", 15)
    print(f"[METRICS] Aggregator starting, interval={interval}s")
    while True:
        write_snapshot(settings)
        time.sleep(interval)

if __name__ == "__main__":
    main()
