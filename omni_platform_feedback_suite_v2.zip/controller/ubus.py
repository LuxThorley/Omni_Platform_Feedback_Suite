import json
import os
import time
from typing import Any, Dict

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

_SETTINGS = _load_settings()
_EVENTS_LOG = os.path.join(BASE_DIR, _SETTINGS["paths"]["bus_events_log"])

os.makedirs(os.path.dirname(_EVENTS_LOG), exist_ok=True)

def publish(topic: str, payload: Dict[str, Any]) -> None:
    """Publish an event to the Universal BUS as a JSON line.

    This is an intentionally simple, append-only implementation that can be
    replaced by a more sophisticated message bus in future.
    """
    event = {
        "ts_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "topic": topic,
        "node_id": _SETTINGS.get("node", {}).get("node_id", "UNKNOWN"),
        "role": _SETTINGS.get("node", {}).get("role", "unspecified"),
        "cluster": _SETTINGS.get("node", {}).get("cluster_name", "default"),
        "payload": payload
    }
    line = json.dumps(event, sort_keys=True)
    with open(_EVENTS_LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def iter_events(limit: int = 100):
    """Iterate over the most recent events up to `limit` entries."""
    if not os.path.exists(_EVENTS_LOG):
        return []

    with open(_EVENTS_LOG, "r", encoding="utf-8") as f:
        lines = f.readlines()[-limit:]

    events = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return events
