import json
import os
import time
from typing import Any, Dict

from . import ubus
from . import license_authority
from . import strategy_engine
from . import policy_synthesizer

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def _load_indexed_policy(settings: Dict[str, Any]) -> Dict[str, Any]:
    path = os.path.join(BASE_DIR, settings["paths"]["policy_index_json"])
    if not os.path.exists(path):
        raise FileNotFoundError(f"Indexed policy not found: {path} (run policy_indexer.py first)")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _load_metrics(settings: Dict[str, Any]) -> Dict[str, Any]:
    path = os.path.join(BASE_DIR, settings["paths"]["metrics_snapshot_json"])
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def evaluate_policy_vs_metrics(policy: Dict[str, Any], metrics: Dict[str, Any]) -> Dict[str, Any]:
    """Compute simple deltas and observations between policy and metrics.

    This is intentionally simple and conservative. You can extend it to perform
    more advanced statistical / AI-guided reasoning.
    """

    # Incorporate strategy engine observations
    strat_obs = strategy_engine.apply_strategies(policy, metrics)
    flags = policy.get("flags", {})
    observations: Dict[str, Any] = {
        "notes": [],
        "suggested_changes": []
    }

    # Example: CPU utilization vs max_safe_cpu_utilization_percent
    cpu_max = None
    for path, flag in flags.items():
        if path.endswith("max_safe_cpu_utilization_percent"):
            cpu_max = flag["value"]
            break

    cpu_percent = metrics.get("health", {}).get("cpu_percent")
    if cpu_max is not None and cpu_percent is not None:
        if cpu_percent < cpu_max * 0.4:
            observations["notes"].append(
                f"CPU utilization ({cpu_percent}%) is far below max_safe_cpu_utilization_percent ({cpu_max}%)."
            )
            observations["suggested_changes"].append({
                "path": "system_optimization.power_and_thermal.prefer_energy_saving_when_idle",
                "reason": "Low CPU load suggests energy-saving mode could be preferred.",
                "proposed_value": True
            })
        elif cpu_percent > cpu_max:
            observations["notes"].append(
                f"CPU utilization ({cpu_percent}%) is above max_safe_cpu_utilization_percent ({cpu_max}%)."
            )
            observations["suggested_changes"].append({
                "path": "system_optimization.cpu.enable_ai_scheduler",
                "reason": "High CPU load suggests more aggressive optimization may be needed.",
                "proposed_value": True
            })

    # Example: firewall tighten events vs policy
    firewall_events = metrics.get("security", {}).get("firewall_tighten_events")
    if firewall_events is not None and firewall_events == 0:
        observations["notes"].append(
            "No firewall tighten events observed; consider whether tighter posture is desired."
        )


    # Merge strategy engine results
    for n in strat_obs.get("notes", []):
        observations["notes"].append(n)
    for c in strat_obs.get("suggested_changes", []):
        observations["suggested_changes"].append(c)
    return observations

def apply_non_destructive_changes(policy: Dict[str, Any], observations: Dict[str, Any]) -> Dict[str, Any]:
    """Apply suggested changes that are non-destructive and allowed by license."""
    caps = license_authority.get_capabilities()
    flags = policy.get("flags", {})

    updated_flags = dict(flags)
    applied = []

    for change in observations.get("suggested_changes", []):
        path = change["path"]
        proposed_value = change["proposed_value"]
        reason = change.get("reason", "")

        # Example gating: treat "prefer_energy_saving_when_idle" as non-destructive optimization
        if "prefer_energy_saving_when_idle" in path:
            if not caps.get("active_optimization_allowed", False):
                continue
            if path in updated_flags and updated_flags[path]["value"] == proposed_value:
                continue
            updated_flags.setdefault(path, {
                "path": path,
                "type": type(proposed_value).__name__,
                "domain": path.split(".", 1)[0] if "." in path else "root"
            })
            updated_flags[path]["value"] = proposed_value
            applied.append({"path": path, "value": proposed_value, "reason": reason})

    new_policy = dict(policy)
    new_policy["flags"] = updated_flags
    new_policy["applied_changes"] = applied
    return new_policy

def loop():
    settings = _load_settings()
    interval = settings["controller"].get("controller_interval_sec", 30)
    print(f"[CTRL] Smart controller starting, interval={interval}s")

    while True:
        try:
            indexed_policy = _load_indexed_policy(settings)
        except FileNotFoundError as e:
            print(f"[CTRL] {e}")
            time.sleep(interval)
            continue

        metrics = _load_metrics(settings)
        license_caps = license_authority.get_capabilities()

        obs = evaluate_policy_vs_metrics(indexed_policy, metrics)
        # Strategy engine already blended into obs via evaluate_policy_vs_metrics
        recommendation_payload = {
            "policy_meta": indexed_policy.get("meta", {}),
            "license_caps": license_caps,
            "metrics_summary": {
                "cycles_total": metrics.get("cycles_total"),
                "network": metrics.get("network", {}),
                "security": metrics.get("security", {})
            },
            "observations": obs
        }
        ubus.publish("policy.recommendation", recommendation_payload)


        # Optionally craft a non-destructive candidate policy and write history
        if license_caps.get("active_optimization_allowed", False):
            candidate = apply_non_destructive_changes(indexed_policy, obs)
            ubus.publish("policy.candidate", {
                "policy_meta": indexed_policy.get("meta", {}),
                "candidate_changes": candidate.get("applied_changes", [])
            })
            # Synthesise a draft policy.json structure (not auto-applied)
            draft = policy_synthesizer.synthesise_draft_policy(obs, indexed_policy.get("meta", {}))
            # Record into policy history log
            policy_synthesizer.write_policy_history(settings, obs.get("suggested_changes", []), {
                "ts_utc": recommendation_payload["policy_meta"].get("timestamp_utc", None),
                "policy_meta": indexed_policy.get("meta", {})
            })

        time.sleep(interval)

def main():
    loop()

if __name__ == "__main__":
    main()
