import json
import os
from typing import Any, Dict, List, Tuple

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def _flatten(obj: Any, prefix: str = "") -> List[Tuple[str, Any]]:
    """Flatten a nested dict (and simple lists) into (path, value) pairs."""
    items: List[Tuple[str, Any]] = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            path = f"{prefix}.{k}" if prefix else k
            items.extend(_flatten(v, path))
    elif isinstance(obj, list):
        for idx, v in enumerate(obj):
            path = f"{prefix}[{idx}]"
            items.extend(_flatten(v, path))
    else:
        items.append((prefix, obj))
    return items

def index_policy(policy_path: str, out_path: str) -> Dict[str, Any]:
    with open(policy_path, "r", encoding="utf-8") as f:
        policy = json.load(f)

    meta = policy.get("meta", {})
    flat = _flatten(policy)

    flags: Dict[str, Dict[str, Any]] = {}
    for path, value in flat:
        # Skip the meta block itself
        if path.startswith("meta."):
            continue
        # Only index leaf nodes (non-dict/non-list) - already ensured
        domain = path.split(".", 1)[0] if "." in path else "root"
        flags[path] = {
            "path": path,
            "value": value,
            "type": type(value).__name__,
            "domain": domain
        }

    indexed = {
        "meta": meta,
        "flags": flags
    }

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(indexed, f, indent=2, sort_keys=True)

    return indexed

def main():
    settings = _load_settings()
    policy_path = os.path.join(BASE_DIR, settings["paths"]["policy_json"])
    out_path = os.path.join(BASE_DIR, settings["paths"]["policy_index_json"])

    print(f"[PIFL] Indexing policy: {policy_path}")
    indexed = index_policy(policy_path, out_path)
    print(f"[PIFL] Wrote indexed policy to: {out_path}")
    print(f"[PIFL] Indexed {len(indexed['flags'])} flags.")

if __name__ == "__main__":
    main()
