import json
import os
import time
from typing import Any, Dict

from . import ubus
from . import license_authority

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def _load_indexed_policy(settings: Dict[str, Any]) -> Dict[str, Any]:
    path = os.path.join(BASE_DIR, settings["paths"]["policy_index_json"])
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _load_metrics(settings: Dict[str, Any]) -> Dict[str, Any]:
    path = os.path.join(BASE_DIR, settings["paths"]["metrics_snapshot_json"])
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def render():
    settings = _load_settings()
    policy = _load_indexed_policy(settings)
    metrics = _load_metrics(settings)
    caps = license_authority.get_capabilities()
    events = ubus.iter_events(limit=10)

    clear()
    node = settings.get('node', {})
    print("=== Omni Platform Feedback Suite :: CLI Dashboard ===")
    print(f"Time : {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}")
    print(f"Node : {node.get('node_id', 'UNKNOWN')} ({node.get('role', 'role-unknown')})")
    print(f"Cluster: {node.get('cluster_name', 'default')}")
    print()

    meta = policy.get("meta", {})
    print("[Policy]")
    print(f"  Name   : {meta.get('policy_name', 'N/A')}")
    print(f"  Version: {meta.get('version', 'N/A')}")
    print()

    print("[License Capabilities]")
    for k, v in caps.items():
        print(f"  {k}: {'ENABLED' if v else 'disabled'}")
    print()

    print("[Metrics Snapshot]")
    if metrics:
        print(f"  Timestamp     : {metrics.get('timestamp_utc', 'N/A')}")
        print(f"  Cycles total  : {metrics.get('cycles_total', 'N/A')}")
        net = metrics.get("network", {})
        print(f"  Net CIDR      : {net.get('last_scan_cidr')}")
        print(f"  Net up hosts  : {net.get('last_up_hosts')}")
        sec = metrics.get("security", {})
        print(f"  Firewall evts : {sec.get('firewall_tighten_events')}")
        print(f"  Suspicious evts: {sec.get('suspicious_process_events')}")
    else:
        print("  No metrics snapshot available yet.")
    print()

    print("[Recent BUS Events]")
    if not events:
        print("  (no events)")
    else:
        for ev in events:
            print(f"  {ev.get('ts_utc')} [{ev.get('topic')}]")
    print()

def main():
    try:
        while True:
            render()
            time.sleep(3)
    except KeyboardInterrupt:
        print("\nExiting dashboard.")

if __name__ == "__main__":
    main()
