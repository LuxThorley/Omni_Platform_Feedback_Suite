import json
import os
from typing import Any, Dict, List

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def _load_base_policy(settings: Dict[str, Any]) -> Dict[str, Any]:
    policy_path = os.path.join(BASE_DIR, settings["paths"]["policy_json"])
    with open(policy_path, "r", encoding="utf-8") as f:
        return json.load(f)

def _ensure_path(obj: Dict[str, Any], path: str) -> Dict[str, Any]:
    """Navigate/create nested dicts along a dotted path, returning the parent dict.

    Example: for path "a.b.c", returns dict containing key 'c' after ensuring a,b exist.
    """
    parts = path.split(".")
    for key in parts[:-1]:
        if key not in obj or not isinstance(obj[key], dict):
            obj[key] = {}
        obj = obj[key]
    return obj

def apply_changes_to_policy(base_policy: Dict[str, Any], changes: List[Dict[str, Any]]) -> Dict[str, Any]:
    new_policy = json.loads(json.dumps(base_policy))  # deep copy
    for change in changes:
        path = change.get("path")
        if not path:
            continue
        value = change.get("proposed_value")
        parent = _ensure_path(new_policy, path)
        leaf_key = path.split(".")[-1]
        parent[leaf_key] = value
    return new_policy

def write_policy_history(settings: Dict[str, Any], changes: List[Dict[str, Any]], meta: Dict[str, Any]) -> None:
    history_path = os.path.join(BASE_DIR, settings["history"]["policy_history_log"])
    os.makedirs(os.path.dirname(history_path), exist_ok=True)
    record = {
        "ts_utc": meta.get("ts_utc"),
        "policy_meta": meta.get("policy_meta", {}),
        "changes": changes,
    }
    with open(history_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, sort_keys=True) + "\n")

def synthesise_draft_policy(observations: Dict[str, Any], policy_meta: Dict[str, Any]) -> Dict[str, Any]:
    settings = _load_settings()
    base_policy = _load_base_policy(settings)
    changes = observations.get("suggested_changes", []) or []
    draft = apply_changes_to_policy(base_policy, changes)
    draft.setdefault("meta", {}).setdefault("derived_from", policy_meta)
    return draft

def main():
    # Simple CLI entry-point for manual use/debugging
    settings = _load_settings()
    print("[SYNTH] This module is primarily driven by the smart controller.")
    print("[SYNTH] To integrate manually, import and call synthesise_draft_policy().")

if __name__ == "__main__":
    main()
