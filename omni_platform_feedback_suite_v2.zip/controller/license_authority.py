import json
import os
from typing import Any, Dict

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "config", "settings.json")

def _load_settings() -> Dict[str, Any]:
    with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def load_license() -> Dict[str, Any]:
    settings = _load_settings()
    license_path = os.path.join(BASE_DIR, settings["paths"]["license_json"])
    with open(license_path, "r", encoding="utf-8") as f:
        return json.load(f)

def get_capabilities() -> Dict[str, Any]:
    lic = load_license()
    return lic.get("capabilities", {})

def is_action_allowed(action: str) -> bool:
    """Check whether a named capability is allowed.

    Example actions:
    - "monitoring_only_mode"
    - "active_optimization_allowed"
    - "destructive_actions_allowed"
    - "kill_suspicious_process_allowed"
    - "firmware_update_allowed_with_admin_consent"
    - "weapons_or_targeting_actions"
    """
    caps = get_capabilities()
    return bool(caps.get(action, False))
