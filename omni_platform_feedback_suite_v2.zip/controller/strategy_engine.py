import json
from typing import Any, Dict, List

StrategyObservation = Dict[str, Any]

def _add_note(obs: Dict[str, Any], note: str) -> None:
    obs.setdefault("notes", []).append(note)

def _add_change(obs: Dict[str, Any], path: str, reason: str, proposed_value: Any) -> None:
    obs.setdefault("suggested_changes", []).append({
        "path": path,
        "reason": reason,
        "proposed_value": proposed_value
    })

def apply_strategies(policy: Dict[str, Any], metrics: Dict[str, Any]) -> StrategyObservation:
    """Apply a set of simple rule-based strategies.

    This is intentionally lightweight but structured so you can replace the internal
    logic with something more advanced (e.g. ML models, external Malcolm AI calls,
    or quantum / hybrid optimisers) without changing the external interface.
    """
    obs: StrategyObservation = {"notes": [], "suggested_changes": []}
    flags = policy.get("flags", {})

    # Example: "luminous" or "health" oriented strategy:
    # if no suspicious events and firewall is allowed, gently suggest a slightly
    # more protective configuration by encouraging energy saving and monitoring.
    sec = metrics.get("security", {})
    susp = sec.get("suspicious_process_events", 0)
    fw_events = sec.get("firewall_tighten_events", 0)

    if susp == 0 and fw_events > 0:
        _add_note(obs, "Security surface appears calm but active firewall tightening is in use.")
        _add_change(
            obs,
            "system_optimization.power_and_thermal.prefer_energy_saving_when_idle",
            "Calm security context allows a more energy-conscious stance while monitoring continues.",
            True,
        )

    # Example: network-aware strategy
    net = metrics.get("network", {})
    up_hosts = net.get("last_up_hosts")
    if isinstance(up_hosts, int) and up_hosts > 50:
        _add_note(obs, f"High number of up hosts detected on the network ({up_hosts}).")
        _add_change(
            obs,
            "network_and_latency_optimization.enable_network_tuning",
            "Dense network suggests maintaining network tuning to preserve latency and throughput.",
            True,
        )

    # Example: respect explicit monitoring-only mode by *avoiding* any suggestion
    # that would require destructive actions.
    core_mode_monitoring = None
    for path, flag in flags.items():
        if path.endswith("core_mode.monitoring_only"):
            core_mode_monitoring = bool(flag.get("value"))
            break

    if core_mode_monitoring:
        _add_note(obs, "Core mode indicates monitoring_only; strategies will avoid suggesting destructive actions.")

    return obs
